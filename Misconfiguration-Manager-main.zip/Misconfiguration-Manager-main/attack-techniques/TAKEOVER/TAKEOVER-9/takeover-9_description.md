# TAKEOVER-9

## Description
Crawl site database links configured with DBA privileges

## MITRE ATT&CK TTPs
- [TTP-ID](https://attack.mitre.org/LINK) - Description

## Requirements
-
-

## Summary

## Impact

## Defensive IDs
- [Prevent-19: Remove unnecessary links to site databases](../../../defense-techniques/PREVENT/PREVENT-19/prevent-19_description.md)

## Examples


## References
- Sanjiv Kawa, [SQLRecon](https://github.com/skahwah/SQLRecon)