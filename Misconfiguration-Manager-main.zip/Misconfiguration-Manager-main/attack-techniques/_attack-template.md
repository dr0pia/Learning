# CODENAME-X

## Description
This is a simple one-line description

## MITRE ATT&CK TTPs
- [TTP-ID](https://attack.mitre.org/LINK) - Description

## Requirements
-
-

## Summary
This is the bulk of the content

## Impact
Brief description of impact

## Defensive IDs
- [ID: Description](Link)

## Subtechniques
-
-

## Examples
Operational examples

## References
- Author, [Title](URL)