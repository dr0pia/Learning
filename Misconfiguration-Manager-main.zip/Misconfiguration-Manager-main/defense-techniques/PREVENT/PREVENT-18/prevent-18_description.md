# PREVENT-18

## Description
Use strong passwords for DBA accounts

## Summary
This is the bulk of the content

## Linked Defensive IDs
- Remove if not relevant


## Associated Offensive IDs


## References
Author, Title, Link