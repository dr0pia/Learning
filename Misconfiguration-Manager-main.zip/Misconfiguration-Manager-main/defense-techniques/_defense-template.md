# CODENAME-X

## Description
This is a simple one-line description

## Summary
This is the bulk of the content

## Linked Defensive IDs
- [ID: Description](Link)

## Associated Offensive IDs
- [ID: Description](Link)

## References
- Author, [Title](Link)